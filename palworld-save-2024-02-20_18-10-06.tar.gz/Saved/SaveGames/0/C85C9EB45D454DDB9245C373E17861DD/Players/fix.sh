#!/bin/bash
ls *.sav | xargs -L1 /root/palworld-save-tools/convert.py --to-json
sed -i 's/None.PalWorldPlayerSaveGame/\/Script\/Pal.PalWorldPlayerSaveGame/g' *.json
ls *.json| xargs -L1 /root/palworld-save-tools/convert.py --force --from-json
